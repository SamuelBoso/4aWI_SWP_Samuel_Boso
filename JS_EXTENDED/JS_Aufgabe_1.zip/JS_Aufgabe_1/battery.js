export class Battery{

    constructor(chargingStatus){
        this.chargingStatus = chargingStatus;
    }
}